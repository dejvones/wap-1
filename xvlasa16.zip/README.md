# WAP 1. proj
- Autor: **David Vlasak (xvlasa16)**
- Řešení testováno: **Ubuntu - Node v18.14.1** a **Merlin - Node v14.17.0**