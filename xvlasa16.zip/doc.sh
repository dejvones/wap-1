#!/bin/bash
npm install --save-dev
./node_modules/jsdoc/jsdoc.js --readme README.md -c jsdoc.json -d doc